# -*- coding: utf-8 -*-

"""
Created On Mon 3 March 2021

@author Nathan

Email: chenchen@bbdservice.com

Instruction: 重庆现代产业研究院
"""

from helper import *
import numpy as np
import warnings
warnings.filterwarnings("ignore")

PATH_FILE = os.path.dirname(__file__)


class ProcessData(Normalize):
    def __init__(self, df):
        self.df = df

    @func_timer
    def scoring_rank(self, field, max_score):
        values = Normalize.normalize_maxmin_field(self.df, field) * max_score

        return values

def main():
    # 合并集群数据
    merge = MergeCsvHadoop()
    merge.merge_data('/user/cqxdcyfzyjy/index_result/20210301/tzjz', 'csv', 'invest.csv')

    # 读取数据
    file_name = 'invest.csv'  #corrected by meijian on 20210323
    weight_name = 'weight_invest.json'
    separator = '\t'
    data_reader = ReadData(path=PATH_FILE, data_file=file_name, sep=separator, weight_file=weight_name)
    # 读取数据
    df_raw = data_reader.read_data_csv()
    # 有重复
    df_raw = df_raw.drop_duplicates('bbd_qyxx_id')
    # 替换正负inf为NA，加inplace参数, T15/T16
    df_raw = df_raw.replace([np.inf, -np.inf], np.nan)
    # 空值填0
    df_raw = df_raw.fillna(0)
    # df_raw.drop('T39', axis=1, inplace=True)
    # T39 发明专利数量数据有误
    df_raw.T39 = df_raw.T39.apply(lambda x: 0)
    # T42与T45一样，T49与T52一样，T39与T60一样
    df_raw['T45'] = df_raw['T42']
    df_raw['T52'] = df_raw['T49']
    df_raw['T60'] = df_raw['T39']
    # 计算T43/T44
    df_raw['T43'] = df_raw[
        ['T_18Y', 'T_19Y', 'T_20Y', 'T_21Y', 'T_22Y', 'T_23Y', 'T_24Y', 'T_25Y', 'T_26Y', 'T_27Y', 'T_28Y', 'T_29Y',
         'T_30Y', 'T_31Y']].sum(axis=1)
    df_raw['T44'] = df_raw[['T_18Y', 'T_19Y', 'T_20Y', 'T_22Y', 'T_29Y', 'T_30Y']].sum(axis=1)
    df_raw.drop(
        ['T_18Y', 'T_19Y', 'T_20Y', 'T_21Y', 'T_22Y', 'T_23Y', 'T_24Y', 'T_25Y', 'T_26Y', 'T_27Y', 'T_28Y', 'T_29Y',
         'T_30Y', 'T_31Y'], axis=1, inplace=True)

    industries = df_raw.industry.unique()
    columns = df_raw.columns
    company_info = ['bbd_qyxx_id', 'industry', 'sub_industry', 'province', 'city', 'region']
    # 指标列
    index_columns = [column for column in columns if column not in company_info]
    # 指标评分列名
    score_columns = [f"{column}_score" if column not in company_info else column for column in columns]
    # 创建评分df
    df_score = pd.DataFrame(columns=score_columns)
    # 填充公司信息
    df_score[company_info] = df_raw[company_info]

    # 处理数据
    for industry in industries:
        df_raw_industry = df_raw[df_raw.industry == industry].copy()
        df_score_industry = df_score[df_score.industry == industry].copy()
        proc = ProcessData(df=df_raw_industry)
        for column in index_columns:
            print(f'{industry}@{column}')
            scores = proc.scoring_rank(field=column, max_score=99)
            df_score_industry[f'{column}_score'] = scores
        df_score.update(df_score_industry)

    # 读取权重
    dict_weight = data_reader.read_weight()
    df_weight = pd.DataFrame(dict_weight)
    # 算总分
    evl = Evaluation(df_score=df_score, df_weight=df_weight)
    evl.second_class()
    evl.first_class()
    evl.total_score()
    evl.result_adjust(6)
    evl.output(PATH_FILE, 'invest_scores.csv')


if __name__ == '__main__':
    main()






