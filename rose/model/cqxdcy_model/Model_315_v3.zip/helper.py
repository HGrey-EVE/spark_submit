# -*- coding: utf-8 -*-

"""
Created On Mon 1 March 2021

@author Nathan

Email: chenchen@bbdservice.com

Instruction: 重庆现代产业研究院
"""

import os
import time
import json
import pandas as pd
import warnings
warnings.filterwarnings("ignore")


def func_timer(func):
    def func_wrapper(*args, **kwargs):
        time_start = time.clock()
        result = func(*args, **kwargs)
        time_end = time.clock()
        time_taken = time_end - time_start
        print(f'{func.__name__} running time: {round(time_taken, 2)} s')
        return result

    return func_wrapper


class ReadData(object):
    def __init__(self, path, data_file, sep, weight_file):
        self.path = path
        self.data_file = data_file
        self.separator = sep
        self.data = None
        self.weight_file = weight_file
        self.weight = None

    @func_timer
    def read_data_csv(self):
        self.data = pd.read_csv(os.path.join(self.path, self.data_file), sep='\t')
        # remove repeating headers in the file merged from c6
        header_index = self.data[self.data['bbd_qyxx_id'] == 'bbd_qyxx_id'].index.tolist()
        self.data.drop(header_index, inplace=True)

        return self.data

    @func_timer
    def read_weight(self):
        with open(os.path.join(self.path, self.weight_file), 'r') as f:
            weight_dict = json.load(f)

            return weight_dict


class MergeCsvHadoop(object):
    def __init__(self):
        self.path = None
        self.file_type = None
        self.file_output = None

    def merge_data(self, path, file_type, file_output):
        self.path = path
        self.file_type = file_type
        self.file_output = file_output
        cmd = f"hadoop fs -getmerge {self.path}/*.{self.file_type} {self.file_output}"
        os.system(cmd)


class Normalize(object):
    @staticmethod
    def normalize_zscore_field(df, field):
        if df[field].max() == df[field].min():
            values = df[[field]].apply(lambda x: x)
        else:
            values = df[[field]].apply(lambda x: (x - x.mean()) / x.std())

        return values

    @staticmethod
    def normalize_maxmin_field(df, field):
        # def normalize(x):
        #     if x.max() == x.min():
        #         return x
        #     else:
        #         return (x - x.min()) / (x.max() - x.min()) * max_score
        # values = df[field].apply(lambda x: normalize(x))
        if df[field].max() == df[field].min():
            values = df[[field]].apply(lambda x: x)
        else:
            values = df[[field]].apply(lambda x: (x - x.min()) / (x.max() - x.min()))

        return values


class Evaluation(object):
    def __init__(self, df_score, df_weight):
        self.df_score = df_score
        self.weight = df_weight

    @func_timer
    def second_class(self):
        second_class_weight = self.weight.index.values
        for weight_name in second_class_weight:
            weight = self.weight.loc[weight_name].value_counts().index.values
            self.df_score[f'{weight_name}_score'] *= weight

    @func_timer
    def first_class(self):
        first_class_weight = self.weight.columns
        for weight_name in first_class_weight:
            second_class_labels = self.weight[self.weight[weight_name].notnull()][f'{weight_name}'].index.tolist()
            second_class_labels = [f'{label}_score' for label in second_class_labels]
            self.df_score[f'{weight_name}'] = self.df_score[second_class_labels].sum(axis=1)

    @func_timer
    def total_score(self):
        first_class_labels = self.weight.columns
        self.df_score['total'] = self.df_score[first_class_labels].sum(axis=1)

    @func_timer
    def result_normalized_trans(self,data, col):
        """
        :param data: 分行业需要正态化的数据
        :param col: 正态化变化列名
        :return: 正太化后的结果
        """
        import numpy as np
        # 获取分位点
        seven_point = np.percentile(data[col], 70, interpolation='linear')
        nine_point = np.percentile(data[col], 90, interpolation='linear')

        # 切分数据
        data_less_seven_point = data.loc[data[col] <= seven_point, :]
        data_middle_point = data.loc[data[col] > seven_point, :]
        data_middle_point = data_middle_point.loc[data_middle_point[col] < nine_point, :]
        data_more_nine_point = data.loc[data[col] >= nine_point, :]

        # 分数转换（原来的最大最小[a,b];线性拉升后的最大最小[c,d]）
        def linear_trans(x, c, d):
            """
            :param x: a,b,c,d原数据以及拉升后的最小最大值
                      0.7分位点以下【x.min(),seven_point】-->>[7,60];
                      0.7-0.9分位点【seven_point，nine_point】-->>[60,80]
                      0.9分位点以上【nine_point,x.max()】-->>【80,99】
            :return:
            """
            a = x.min()
            b = x.max()
            k = (d - c) / (b - a)
            j = c - a * k
            return k * x + j

        data_less_seven_point[col] = linear_trans(data_less_seven_point[col], 7, 60)
        data_middle_point[col] = linear_trans(data_middle_point[col], 60, 80)
        data_more_nine_point[col] = linear_trans(data_more_nine_point[col], 80, 99)

        # 由于存在某些模块的最大最小都为0，结果为空值，需要进行填充0值
        data_less_seven_point[col] = data_less_seven_point[col].fillna(0)

        # 合并结果
        data_trans = pd.concat([data_less_seven_point,
                                data_middle_point,
                                data_more_nine_point])

        return data_trans

    def trans_all(self,data, trans_col):
        """
        对结果数据的得分和模块得分均进行转化
        :param data:
        :return:
        """
        for col in trans_col:
            data = self.result_normalized_trans(data, col)
            data = data.drop_duplicates('bbd_qyxx_id')
        return data

    def result_adjust(self,n):
        "n表示需要调整的模块分数跟总分的个数，从倒数第n个位置开始调整"
        print('score adjust...')
        data_risk_xcl = self.df_score.loc[self.df_score['industry'] == '新材料', :]
        data_risk_xny = self.df_score.loc[self.df_score['industry'] == '新能源', :]
        data_risk_jcdl = self.df_score.loc[self.df_score['industry'] == '集成电路', :]

        trans_col = list(self.df_score.columns)[-n:]
        data_xcl_result_trans = self.trans_all(data_risk_xcl, trans_col)
        data_xny_result_trans = self.trans_all(data_risk_xny, trans_col)
        data_jcdl_result_trans = self.trans_all(data_risk_jcdl, trans_col)

        self.df_score = pd.concat([data_xcl_result_trans,
                                   data_xny_result_trans,
                                   data_jcdl_result_trans])

    @func_timer
    def output(self, path, file):
        print('Output...')
        self.df_score.to_csv(os.path.join(path, file), encoding='utf-8', index=False)

